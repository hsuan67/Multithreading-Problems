package dining_philosophers;

public class Fork {
	private int number;
	public Fork(int number) {
		// TODO Auto-generated constructor stub
		this.number=number;
		
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	
	

}
